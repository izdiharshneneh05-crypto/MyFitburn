import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'screens/home_screen.dart';
import 'services/notification_service.dart';
import 'state/history_controller.dart';
import 'state/profile_controller.dart';
import 'state/session_controller.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await _startApp();
  } catch (e, st) {
    // Never leave the user stuck on the splash screen: show what went wrong.
    runApp(StartupErrorApp(error: '$e\n\n$st'));
  }
}

Future<void> _startApp() async {
  // Notifications are optional for launching. If the plugin fails or hangs,
  // open the app anyway instead of freezing on the splash screen.
  try {
    await NotificationService.instance
        .init()
        .timeout(const Duration(seconds: 5));
  } catch (e) {
    debugPrint('Notification init failed: $e');
  }
  try {
    await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp])
        .timeout(const Duration(seconds: 2));
  } catch (_) {}

  final prefs = await SharedPreferences.getInstance()
      .timeout(const Duration(seconds: 10));
  final profile = ProfileController(prefs);
  final history = HistoryController(prefs);
  // Restores an in-progress workout (if any) so a killed app resumes exactly.
  final session = SessionController(prefs, profile);

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: profile),
        ChangeNotifierProvider.value(value: history),
        ChangeNotifierProvider.value(value: session),
      ],
      child: const FitBurnApp(),
    ),
  );
}

/// Shown only if startup throws, so the error is visible on the phone.
class StartupErrorApp extends StatelessWidget {
  const StartupErrorApp({super.key, required this.error});

  final String error;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: Scaffold(
        appBar: AppBar(title: const Text('FitBurn could not start')),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: SelectableText(error),
        ),
      ),
    );
  }
}

class FitBurnApp extends StatelessWidget {
  const FitBurnApp({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = buildTheme();
    return MaterialApp(
      title: 'FitBurn',
      debugShowCheckedModeBanner: false,
      theme: theme,
      darkTheme: theme,
      themeMode: ThemeMode.dark,
      home: const HomeScreen(),
    );
  }
}
