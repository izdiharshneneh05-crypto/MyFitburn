import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'screens/home_screen.dart';
import 'services/notification_service.dart';
import 'state/history_controller.dart';
import 'state/profile_controller.dart';
import 'state/session_controller.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.instance.init();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  final prefs = await SharedPreferences.getInstance();
  final profile = ProfileController(prefs);
  final history = HistoryController(prefs);
  // Restores an in-progress workout (if any) so a killed app resumes exactly.
  final session = SessionController(prefs, profile);

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: profile),
        ChangeNotifierProvider.value(value: history),
        ChangeNotifierProvider.value(value: session),
      ],
      child: const FitBurnApp(),
    ),
  );
}

class FitBurnApp extends StatelessWidget {
  const FitBurnApp({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = buildTheme();
    return MaterialApp(
      title: 'FitBurn',
      debugShowCheckedModeBanner: false,
      theme: theme,
      darkTheme: theme,
      themeMode: ThemeMode.dark,
      home: const HomeScreen(),
    );
  }
}
