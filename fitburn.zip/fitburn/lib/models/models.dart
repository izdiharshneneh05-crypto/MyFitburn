import 'package:flutter/painting.dart' show Color;

import '../services/calories.dart';
import '../utils/format.dart';

enum Equipment { treadmill, dumbbell, machine, bodyweight }

extension EquipmentLabel on Equipment {
  String get label => switch (this) {
        Equipment.treadmill => 'Treadmill',
        Equipment.dumbbell => 'Dumbbells',
        Equipment.machine => 'Machine',
        Equipment.bodyweight => 'Bodyweight',
      };
}

/// One exercise in a workout day. Either rep-based ([reps]) or timed
/// ([durationSec]) — treadmill blocks, planks, carries and HIIT intervals are
/// timed.
class Exercise {
  const Exercise({
    required this.id,
    required this.name,
    required this.equipment,
    required this.sets,
    this.reps,
    this.durationSec,
    this.perSide = false,
    required this.restSec,
    required this.met,
    this.restMet = Calories.idleMet,
    required this.cue,
    this.setting,
  }) : assert((reps == null) != (durationSec == null),
            'Give either reps or durationSec');

  /// Average time under tension per rep, used to estimate work time.
  static const double secondsPerRep = 3.5;

  final String id;
  final String name;
  final Equipment equipment;
  final int sets;
  final int? reps;
  final int? durationSec;
  final bool perSide;

  /// Rest after each set (also the changeover after the last set).
  final int restSec;

  /// Intensity while working.
  final double met;

  /// Intensity while resting — higher for active recovery (HIIT walk).
  final double restMet;

  /// Short coaching cue shown during the set.
  final String cue;

  /// Machine/treadmill setting, e.g. "5.0 km/h · 12% incline".
  final String? setting;

  bool get isTimed => durationSec != null;

  int repWorkSec(int r) => (r * secondsPerRep * (perSide ? 2 : 1)).round();

  int get plannedWorkSec => isTimed ? durationSec! : repWorkSec(reps!);

  /// Work plus the rest that follows — used for time-weighted progress.
  int get plannedSetSec => plannedWorkSec + restSec;

  String get prescription {
    if (isTimed) {
      final d = fmtDur(durationSec!);
      return sets == 1 ? d : '$sets × $d';
    }
    return '$sets × $reps${perSide ? ' / side' : ''}';
  }
}

class WorkoutDay {
  const WorkoutDay({
    required this.id,
    required this.title,
    required this.focus,
    required this.summary,
    required this.color,
    required this.exercises,
  });

  final int id;
  final String title;
  final String focus;
  final String summary;
  final Color color;
  final List<Exercise> exercises;

  int get totalSets => exercises.fold<int>(0, (s, e) => s + e.sets);

  /// Planned session length (work + rests, no rest after the final set).
  int get plannedSec =>
      exercises.fold<int>(0, (s, e) => s + e.sets * e.plannedSetSec) -
      exercises.last.restSec;

  int get plannedMinutes => (plannedSec / 60).round();

  double plannedKcal(double weightKg) {
    var kcal = 0.0;
    for (final e in exercises) {
      kcal += Calories.fromMet(
          e.met, (e.sets * e.plannedWorkSec).toDouble(), weightKg);
      kcal += Calories.fromMet(
          e.restMet, (e.sets * e.restSec).toDouble(), weightKg);
    }
    return kcal;
  }
}

/// A finished, saved workout.
class WorkoutLog {
  const WorkoutLog({
    required this.dayId,
    required this.dayTitle,
    required this.date,
    required this.durationSec,
    required this.kcal,
    required this.setsDone,
    required this.totalSets,
  });

  final int dayId;
  final String dayTitle;
  final DateTime date;
  final int durationSec;
  final double kcal;
  final int setsDone;
  final int totalSets;

  int get completionPct =>
      totalSets == 0 ? 0 : (setsDone * 100 / totalSets).round();

  Map<String, dynamic> toJson() => {
        'dayId': dayId,
        'dayTitle': dayTitle,
        'date': date.millisecondsSinceEpoch,
        'durationSec': durationSec,
        'kcal': kcal,
        'setsDone': setsDone,
        'totalSets': totalSets,
      };

  factory WorkoutLog.fromJson(Map<String, dynamic> j) => WorkoutLog(
        dayId: j['dayId'] as int,
        dayTitle: j['dayTitle'] as String,
        date: DateTime.fromMillisecondsSinceEpoch(j['date'] as int),
        durationSec: j['durationSec'] as int,
        kcal: (j['kcal'] as num).toDouble(),
        setsDone: j['setsDone'] as int,
        totalSets: j['totalSets'] as int,
      );
}
