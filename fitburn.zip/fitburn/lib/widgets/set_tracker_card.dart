import 'package:flutter/material.dart';

import '../models/models.dart';
import '../state/session_controller.dart';
import '../theme.dart';
import '../utils/format.dart';
import 'common.dart';

/// The current exercise: cues, set dots, rep stepper or set timer, and the
/// big "complete set" action.
class SetTrackerCard extends StatelessWidget {
  const SetTrackerCard({super.key, required this.s, required this.index});

  final SessionController s;
  final int index;

  @override
  Widget build(BuildContext context) {
    final d = s.day!;
    final e = d.exercises[index];
    final done = s.doneSets(index);
    final finished = done >= e.sets;

    return AppCard(
      borderColor: d.color.withAlpha(110),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              EquipmentChip(e.equipment),
              const Spacer(),
              Text(
                finished ? 'COMPLETE' : 'SET ${done + 1} OF ${e.sets}',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                  color: d.color,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            e.name,
            style: const TextStyle(
                fontSize: 26, fontWeight: FontWeight.w800, height: 1.1),
          ),
          if (e.setting != null) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.speed_rounded,
                    size: 18, color: AppColors.cool),
                const SizedBox(width: 6),
                Flexible(
                  child: Text(
                    e.setting!,
                    style: const TextStyle(
                        color: AppColors.cool, fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
          ],
          const SizedBox(height: 8),
          Text(
            e.cue,
            style: const TextStyle(
                color: AppColors.textDim, fontSize: 14, height: 1.35),
          ),
          const SizedBox(height: 16),
          SetDots(total: e.sets, done: done, color: d.color),
          if (done > 0 && !e.isTimed) ...[
            const SizedBox(height: 10),
            Text(
              'Logged: ${s.loggedFor(index).join(' · ')} reps',
              style: const TextStyle(color: AppColors.textDim, fontSize: 13),
            ),
          ],
          const SizedBox(height: 18),
          if (finished)
            _Finished(s: s, index: index, color: d.color)
          else if (e.isTimed)
            _TimedControls(s: s, index: index, exercise: e, color: d.color)
          else
            _RepControls(s: s, index: index, exercise: e, color: d.color),
        ],
      ),
    );
  }
}

class _RepControls extends StatelessWidget {
  const _RepControls({
    required this.s,
    required this.index,
    required this.exercise,
    required this.color,
  });

  final SessionController s;
  final int index;
  final Exercise exercise;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            _StepButton(
              icon: Icons.remove_rounded,
              onTap: () => s.adjustReps(index, -1),
            ),
            Expanded(
              child: Column(
                children: [
                  Text(
                    '${s.repDraft(index)}',
                    style: const TextStyle(
                      fontSize: 60,
                      fontWeight: FontWeight.w900,
                      height: 1,
                      fontFeatures: tabular,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    exercise.perSide ? 'reps per side' : 'reps',
                    style: const TextStyle(color: AppColors.textDim),
                  ),
                ],
              ),
            ),
            _StepButton(
              icon: Icons.add_rounded,
              onTap: () => s.adjustReps(index, 1),
            ),
          ],
        ),
        const SizedBox(height: 18),
        BigButton(
          label: 'COMPLETE SET',
          icon: Icons.check_rounded,
          color: color,
          onPressed: s.isPaused ? null : () => s.completeSet(index),
        ),
        if (s.doneSets(index) > 0) _UndoButton(s: s, index: index),
      ],
    );
  }
}

class _TimedControls extends StatelessWidget {
  const _TimedControls({
    required this.s,
    required this.index,
    required this.exercise,
    required this.color,
  });

  final SessionController s;
  final int index;
  final Exercise exercise;
  final Color color;

  @override
  Widget build(BuildContext context) {
    if (s.isWorking(index)) {
      return Column(
        children: [
          Center(
            child: Text(
              fmtClock(s.phaseRemainingSec),
              style: TextStyle(
                fontSize: 72,
                fontWeight: FontWeight.w900,
                color: color,
                height: 1,
                fontFeatures: tabular,
              ),
            ),
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: s.phaseProgress,
              minHeight: 10,
              color: color,
              backgroundColor: AppColors.line,
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 64,
                  child: OutlinedButton(
                    onPressed: s.cancelTimedSet,
                    child: const Text('Cancel'),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 2,
                child: SizedBox(
                  height: 64,
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: color),
                    onPressed: s.isPaused ? null : s.finishTimedSetEarly,
                    icon: const Icon(Icons.check_rounded, size: 26),
                    label: const Text('DONE'),
                  ),
                ),
              ),
            ],
          ),
        ],
      );
    }

    return Column(
      children: [
        Center(
          child: Text(
            fmtClock(exercise.durationSec!),
            style: const TextStyle(
              fontSize: 60,
              fontWeight: FontWeight.w900,
              height: 1,
              fontFeatures: tabular,
            ),
          ),
        ),
        const SizedBox(height: 4),
        const Center(
          child: Text('per set', style: TextStyle(color: AppColors.textDim)),
        ),
        const SizedBox(height: 18),
        BigButton(
          label: 'START ${fmtDur(exercise.durationSec!).toUpperCase()}',
          icon: Icons.play_arrow_rounded,
          color: color,
          onPressed: s.isPaused || s.anyWorking
              ? null
              : () => s.startTimedSet(index),
        ),
        TextButton(
          onPressed: s.isPaused ? null : () => s.completeSet(index),
          child: const Text('Already done? Log it without the timer'),
        ),
        if (s.doneSets(index) > 0) _UndoButton(s: s, index: index),
      ],
    );
  }
}

class _Finished extends StatelessWidget {
  const _Finished({required this.s, required this.index, required this.color});
  final SessionController s;
  final int index;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(Icons.check_circle_rounded, color: color, size: 28),
        const SizedBox(width: 10),
        const Expanded(
          child: Text('All sets done',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
        ),
        _UndoButton(s: s, index: index),
      ],
    );
  }
}

class _UndoButton extends StatelessWidget {
  const _UndoButton({required this.s, required this.index});
  final SessionController s;
  final int index;

  @override
  Widget build(BuildContext context) {
    return TextButton.icon(
      onPressed: s.anyWorking ? null : () => s.undoLastSet(index),
      icon: const Icon(Icons.undo_rounded, size: 18),
      label: const Text('Undo last set'),
    );
  }
}

class _StepButton extends StatelessWidget {
  const _StepButton({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surfaceHigh,
      shape: const CircleBorder(side: BorderSide(color: AppColors.line)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: SizedBox(
          width: 76,
          height: 76,
          child: Icon(icon, size: 36),
        ),
      ),
    );
  }
}
