import 'package:flutter/material.dart';

import '../services/calories.dart';
import '../state/session_controller.dart';
import '../theme.dart';
import '../utils/format.dart';
import 'common.dart';

/// Big, glanceable rest countdown with +15 s and Skip.
class RestTimerPanel extends StatelessWidget {
  const RestTimerPanel({super.key, required this.s});
  final SessionController s;

  @override
  Widget build(BuildContext context) {
    final sec = s.phaseRemainingSec;
    final urgent = sec <= 3;
    final color = urgent ? AppColors.hot : AppColors.cool;
    final restingAfter = s.day!.exercises[s.phase!.exerciseIndex];
    final activeRecovery = restingAfter.restMet > Calories.idleMet;

    return AppCard(
      color: AppColors.cool.withAlpha(20),
      borderColor: color.withAlpha(130),
      child: Column(
        children: [
          Row(
            children: [
              Icon(Icons.timer_rounded, color: color),
              const SizedBox(width: 8),
              Text(
                activeRecovery ? 'RECOVERY WALK' : 'REST',
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.6,
                ),
              ),
              const Spacer(),
              if (s.isPaused)
                const Text('PAUSED',
                    style: TextStyle(
                        color: AppColors.textDim,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.4)),
            ],
          ),
          const SizedBox(height: 4),
          AnimatedDefaultTextStyle(
            duration: const Duration(milliseconds: 200),
            style: TextStyle(
              fontSize: urgent ? 92 : 84,
              fontWeight: FontWeight.w900,
              color: color,
              height: 1.05,
              fontFeatures: tabular,
            ),
            child: Text(fmtClock(sec)),
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: s.phaseProgress,
              minHeight: 10,
              color: color,
              backgroundColor: AppColors.line,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Next: ${s.nextUpLabel}',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
          ),
          if (activeRecovery) ...[
            const SizedBox(height: 4),
            const Text(
              'Keep walking at an easy pace.',
              style: TextStyle(color: AppColors.textDim, fontSize: 13),
            ),
          ],
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 60,
                  child: OutlinedButton.icon(
                    onPressed: s.isPaused ? null : () => s.extendRest(15),
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('15 s'),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: SizedBox(
                  height: 60,
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: AppColors.cool,
                      foregroundColor: AppColors.onAccent,
                    ),
                    onPressed: s.skipRest,
                    icon: const Icon(Icons.skip_next_rounded),
                    label: const Text('SKIP'),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
