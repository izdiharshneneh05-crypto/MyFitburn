import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/notification_service.dart';
import '../state/profile_controller.dart';
import '../theme.dart';
import '../widgets/common.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _weight;

  @override
  void initState() {
    super.initState();
    final p = context.read<ProfileController>();
    _weight = TextEditingController(text: p.displayWeight.toStringAsFixed(1));
  }

  @override
  void dispose() {
    _weight.dispose();
    super.dispose();
  }

  void _snack(String msg) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));

  Future<void> _saveWeight() async {
    final p = context.read<ProfileController>();
    final v = double.tryParse(_weight.text.trim().replaceAll(',', '.'));
    final kg = v == null ? null : (p.useLbs ? v * ProfileController.kgPerLb : v);
    if (kg == null || kg < 30 || kg > 300) {
      _snack('Enter a weight between 30 and 300 kg (66–660 lb).');
      return;
    }
    await p.setWeightKg(kg);
    if (!mounted) return;
    FocusScope.of(context).unfocus();
    _snack('Weight saved');
  }

  Future<void> _setUnit(bool lbs) async {
    final p = context.read<ProfileController>();
    await p.setUseLbs(lbs);
    _weight.text = p.displayWeight.toStringAsFixed(1);
  }

  Future<void> _testAlert() async {
    final n = NotificationService.instance;
    await n.ensurePermissions();
    if (await n.shouldAskExactAlarms()) await n.requestExactAlarms();
    await n.scheduleAlert(
      id: 99,
      atMs: DateTime.now().millisecondsSinceEpoch + 10000,
      title: 'Test alert ✅',
      body: 'Background alerts are working. Go lift something heavy!',
    );
    if (!mounted) return;
    _snack('Lock your phone now — the alert rings in 10 seconds.');
  }

  @override
  Widget build(BuildContext context) {
    final p = context.watch<ProfileController>();

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 32),
        children: [
          const SectionLabel('Body weight', top: 8),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Used to estimate calories burned.',
                    style: TextStyle(color: AppColors.textDim)),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _weight,
                        keyboardType: const TextInputType.numberWithOptions(
                            decimal: true),
                        textInputAction: TextInputAction.done,
                        onSubmitted: (_) => _saveWeight(),
                        style: const TextStyle(
                            fontSize: 26, fontWeight: FontWeight.w800),
                        decoration:
                            InputDecoration(suffixText: p.weightUnit),
                      ),
                    ),
                    const SizedBox(width: 12),
                    SizedBox(
                      height: 64,
                      child: FilledButton(
                        onPressed: _saveWeight,
                        child: const Text('SAVE'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: SegmentedButton<bool>(
                    showSelectedIcon: false,
                    segments: const [
                      ButtonSegment(value: false, label: Text('kg')),
                      ButtonSegment(value: true, label: Text('lb')),
                    ],
                    selected: {p.useLbs},
                    onSelectionChanged: (v) => _setUnit(v.first),
                  ),
                ),
              ],
            ),
          ),
          const SectionLabel('During workouts'),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
            child: SwitchListTile(
              value: p.keepScreenOn,
              onChanged: p.setKeepScreenOn,
              title: const Text('Keep screen awake',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text(
                'Timers stay accurate with the screen off either way.',
                style: TextStyle(color: AppColors.textDim),
              ),
            ),
          ),
          const SectionLabel('Background alerts'),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Check that the rest alarm reaches you with the screen '
                  'locked.',
                  style: TextStyle(height: 1.4),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: _testAlert,
                    icon: const Icon(Icons.notifications_active_rounded),
                    label: const Text('Send test alert in 10 s'),
                  ),
                ),
                const SizedBox(height: 14),
                const Text(
                  'Alerts late or missing? In Android Settings → Apps → '
                  'FitBurn: allow Notifications and "Alarms & reminders", '
                  'and set Battery to "Unrestricted". Some phones (Xiaomi, '
                  'Huawei, Samsung) also need FitBurn excluded from their '
                  'own battery savers.',
                  style: TextStyle(
                      color: AppColors.textDim, fontSize: 13, height: 1.4),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
