import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../services/notification_service.dart';
import '../state/profile_controller.dart';
import '../state/session_controller.dart';
import '../theme.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import 'workout_screen.dart';

class DayDetailScreen extends StatelessWidget {
  const DayDetailScreen({super.key, required this.day});
  final WorkoutDay day;

  @override
  Widget build(BuildContext context) {
    final kg = context.watch<ProfileController>().weightKg;
    final session = context.watch<SessionController>();
    final resuming = session.isActive && session.day!.id == day.id;

    return Scaffold(
      appBar: AppBar(title: Text('Day ${day.id}')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        children: [
          AppCard(
            color: day.color.withAlpha(24),
            borderColor: day.color.withAlpha(90),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(day.title,
                    style: const TextStyle(
                        fontSize: 26, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text(day.focus,
                    style: TextStyle(
                        color: day.color, fontWeight: FontWeight.w700)),
                const SizedBox(height: 10),
                Text(day.summary,
                    style: const TextStyle(
                        color: AppColors.textDim, height: 1.4)),
                const SizedBox(height: 14),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    StatPill(
                        icon: Icons.schedule_rounded,
                        text: '~${day.plannedMinutes} min'),
                    StatPill(
                      icon: Icons.local_fire_department_rounded,
                      color: AppColors.hot,
                      text: '~${day.plannedKcal(kg).round()} kcal',
                    ),
                    StatPill(
                        icon: Icons.repeat_rounded,
                        text: '${day.totalSets} sets'),
                  ],
                ),
              ],
            ),
          ),
          const SectionLabel('Exercises'),
          for (var i = 0; i < day.exercises.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _ExerciseTile(
                  number: i + 1, exercise: day.exercises[i], color: day.color),
            ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: BigButton(
          label: resuming ? 'RESUME WORKOUT' : 'START WORKOUT',
          icon: Icons.play_arrow_rounded,
          color: day.color,
          onPressed: () => _start(context),
        ),
      ),
    );
  }

  Future<void> _start(BuildContext context) async {
    final session = context.read<SessionController>();
    final nav = Navigator.of(context);
    void openWorkout() => nav.pushReplacement(
        MaterialPageRoute(builder: (_) => const WorkoutScreen()));

    if (session.isActive && session.day!.id == day.id) {
      openWorkout();
      return;
    }
    if (session.isActive) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: AppColors.surfaceHigh,
          title: const Text('Another workout is running'),
          content: Text(
              'Day ${session.day!.id} is still in progress. Discard it and '
              'start Day ${day.id}?'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Cancel')),
            TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Discard & start',
                  style: TextStyle(color: AppColors.hot)),
            ),
          ],
        ),
      );
      if (ok != true) return;
    }

    final notifications = NotificationService.instance;
    await notifications.ensurePermissions();
    if (await notifications.shouldAskExactAlarms() && context.mounted) {
      final allow = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: AppColors.surfaceHigh,
          title: const Text('On-time rest alerts'),
          content: const Text(
            'To ring the rest timer exactly on time while your screen is '
            'locked, Android needs the "Alarms & reminders" permission. '
            'Turn it on for FitBurn on the next screen.',
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Not now')),
            TextButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Allow',
                    style: TextStyle(color: AppColors.accent))),
          ],
        ),
      );
      if (allow == true) {
        await notifications.requestExactAlarms();
      } else {
        await notifications.markExactAlarmsAsked();
      }
    }

    await session.start(day);
    if (!context.mounted) return;
    openWorkout();
  }
}

class _ExerciseTile extends StatelessWidget {
  const _ExerciseTile({
    required this.number,
    required this.exercise,
    required this.color,
  });

  final int number;
  final Exercise exercise;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final e = exercise;
    return AppCard(
      padding: const EdgeInsets.all(14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 34,
            height: 34,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: color.withAlpha(30),
              shape: BoxShape.circle,
            ),
            child: Text('$number',
                style: TextStyle(color: color, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(e.name,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Text(
                  e.restSec > 0
                      ? '${e.prescription} · rest ${fmtDur(e.restSec)}'
                      : e.prescription,
                  style: const TextStyle(color: AppColors.textDim),
                ),
                if (e.setting != null) ...[
                  const SizedBox(height: 3),
                  Text(e.setting!,
                      style: const TextStyle(
                          color: AppColors.cool,
                          fontSize: 13,
                          fontWeight: FontWeight.w600)),
                ],
              ],
            ),
          ),
          Icon(equipmentIcon(e.equipment), color: AppColors.textDim),
        ],
      ),
    );
  }
}
