import 'package:flutter/material.dart';

import '../data/plan.dart';
import '../models/models.dart';
import '../theme.dart';
import '../utils/format.dart';
import '../widgets/common.dart';

class SummaryScreen extends StatelessWidget {
  const SummaryScreen({super.key, required this.log});
  final WorkoutLog log;

  @override
  Widget build(BuildContext context) {
    final color = planDayById(log.dayId)?.color ?? AppColors.accent;

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 32, 20, 24),
          children: [
            Center(
              child: Container(
                width: 104,
                height: 104,
                decoration: BoxDecoration(
                  color: color.withAlpha(40),
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.check_rounded, size: 64, color: color),
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'Workout complete',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 4),
            Text(
              'Day ${log.dayId} · ${log.dayTitle}',
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.textDim),
            ),
            const SizedBox(height: 26),
            Row(
              children: [
                Expanded(
                  child: _Stat(
                    icon: Icons.local_fire_department_rounded,
                    color: AppColors.hot,
                    value: '${log.kcal.round()}',
                    label: 'kcal burned',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _Stat(
                    icon: Icons.timer_outlined,
                    color: AppColors.cool,
                    value: fmtClock(log.durationSec),
                    label: 'duration',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _Stat(
                    icon: Icons.repeat_rounded,
                    color: color,
                    value: '${log.setsDone}/${log.totalSets}',
                    label: 'sets',
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _Stat(
                    icon: Icons.donut_large_rounded,
                    color: color,
                    value: '${log.completionPct}%',
                    label: 'complete',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const AppCard(
              child: Text(
                'Calories are an estimate (MET method, roughly ±25%). '
                'For fat loss the weekly trend matters more than any '
                'single number — pair these sessions with a moderate '
                'calorie deficit and enough protein.',
                style: TextStyle(color: AppColors.textDim, height: 1.4),
              ),
            ),
            const SizedBox(height: 24),
            BigButton(
              label: 'BACK TO HOME',
              icon: Icons.home_rounded,
              color: color,
              onPressed: () =>
                  Navigator.of(context).popUntil((r) => r.isFirst),
            ),
          ],
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({
    required this.icon,
    required this.color,
    required this.value,
    required this.label,
  });

  final IconData icon;
  final Color color;
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color),
          const SizedBox(height: 10),
          Text(value,
              style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  fontFeatures: tabular)),
          Text(label, style: const TextStyle(color: AppColors.textDim)),
        ],
      ),
    );
  }
}
