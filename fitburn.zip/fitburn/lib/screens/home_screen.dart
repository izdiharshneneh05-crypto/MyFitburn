import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/plan.dart';
import '../models/models.dart';
import '../state/history_controller.dart';
import '../state/profile_controller.dart';
import '../state/session_controller.dart';
import '../theme.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import 'day_detail_screen.dart';
import 'settings_screen.dart';
import 'workout_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final history = context.watch<HistoryController>();
    final profile = context.watch<ProfileController>();
    final upNext = history.recommendedDayId;

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
          children: [
            Row(
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'FitBurn',
                        style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -0.8,
                        ),
                      ),
                      SizedBox(height: 2),
                      Text('4-day fat-loss gym plan',
                          style: TextStyle(color: AppColors.textDim)),
                    ],
                  ),
                ),
                IconButton(
                  iconSize: 28,
                  style: IconButton.styleFrom(
                    backgroundColor: AppColors.surfaceHigh,
                    minimumSize: const Size(52, 52),
                  ),
                  tooltip: 'Settings',
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const SettingsScreen()),
                  ),
                  icon: const Icon(Icons.tune_rounded),
                ),
              ],
            ),
            const SizedBox(height: 18),
            const _ResumeBanner(),
            if (!profile.hasWeight) ...[
              const _SetWeightCard(),
              const SizedBox(height: 12),
            ],
            _WeekCard(history: history),
            const SectionLabel('Your plan'),
            for (final day in workoutPlan)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: _DayCard(
                  day: day,
                  doneThisWeek: history.doneThisWeek(day.id),
                  upNext: day.id == upNext,
                  weightKg: profile.weightKg,
                ),
              ),
            const SectionLabel('Coach notes', top: 12),
            const _CoachNotes(),
          ],
        ),
      ),
    );
  }
}

class _ResumeBanner extends StatelessWidget {
  const _ResumeBanner();

  @override
  Widget build(BuildContext context) {
    final s = context.watch<SessionController>();
    if (!s.isActive) return const SizedBox.shrink();
    final d = s.day!;
    final status = s.isPaused
        ? 'Paused'
        : s.isResting
            ? 'Resting · ${fmtClock(s.phaseRemainingSec)}'
            : fmtClock(s.elapsedSec);

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AppCard(
        color: d.color,
        borderColor: d.color,
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const WorkoutScreen()),
        ),
        child: Row(
          children: [
            const Icon(Icons.play_circle_fill_rounded,
                size: 40, color: AppColors.onAccent),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'WORKOUT IN PROGRESS',
                    style: TextStyle(
                      color: AppColors.onAccent,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.2,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'Day ${d.id} · ${s.progressPct}% · $status',
                    style: const TextStyle(
                      color: AppColors.onAccent,
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded,
                color: AppColors.onAccent, size: 30),
          ],
        ),
      ),
    );
  }
}

class _SetWeightCard extends StatelessWidget {
  const _SetWeightCard();

  @override
  Widget build(BuildContext context) {
    return AppCard(
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const SettingsScreen()),
      ),
      child: const Row(
        children: [
          Icon(Icons.monitor_weight_outlined, color: AppColors.hot, size: 30),
          SizedBox(width: 14),
          Expanded(
            child: Text(
              'Set your body weight for accurate calorie estimates.',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
          Icon(Icons.chevron_right_rounded, color: AppColors.textDim),
        ],
      ),
    );
  }
}

class _WeekCard extends StatelessWidget {
  const _WeekCard({required this.history});
  final HistoryController history;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('This week',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const Spacer(),
              Text(
                '${history.daysDoneThisWeek} / 4 workouts',
                style: const TextStyle(
                    color: AppColors.textDim, fontWeight: FontWeight.w600),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              for (final d in workoutPlan) ...[
                Expanded(
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    height: 10,
                    decoration: BoxDecoration(
                      color: history.doneThisWeek(d.id)
                          ? d.color
                          : AppColors.line,
                      borderRadius: BorderRadius.circular(6),
                    ),
                  ),
                ),
                if (d != workoutPlan.last) const SizedBox(width: 6),
              ],
            ],
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              StatPill(
                icon: Icons.local_fire_department_rounded,
                color: AppColors.hot,
                text: '${history.kcalThisWeek.round()} kcal',
              ),
              StatPill(
                icon: Icons.schedule_rounded,
                text: '${history.minutesThisWeek} min',
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _DayCard extends StatelessWidget {
  const _DayCard({
    required this.day,
    required this.doneThisWeek,
    required this.upNext,
    required this.weightKg,
  });

  final WorkoutDay day;
  final bool doneThisWeek;
  final bool upNext;
  final double weightKg;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      borderColor: upNext ? day.color.withAlpha(140) : null,
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => DayDetailScreen(day: day)),
      ),
      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: day.color.withAlpha(34),
              borderRadius: BorderRadius.circular(18),
            ),
            child: doneThisWeek
                ? Icon(Icons.check_rounded, color: day.color, size: 32)
                : Text(
                    '${day.id}',
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      color: day.color,
                    ),
                  ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      'DAY ${day.id}',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.4,
                        color: day.color,
                      ),
                    ),
                    if (upNext) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: day.color,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Text(
                          'UP NEXT',
                          style: TextStyle(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                            color: AppColors.onAccent,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  day.title,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 2),
                Text(day.focus,
                    style: const TextStyle(color: AppColors.textDim)),
                const SizedBox(height: 8),
                Text(
                  '~${day.plannedMinutes} min · '
                  '~${day.plannedKcal(weightKg).round()} kcal · '
                  '${day.totalSets} sets',
                  style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textDim),
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: AppColors.textDim),
        ],
      ),
    );
  }
}

class _CoachNotes extends StatelessWidget {
  const _CoachNotes();

  static const _notes = [
    (
      Icons.restaurant_rounded,
      'Fat loss is mostly set in the kitchen. Aim for a moderate deficit '
          '(about 300–500 kcal/day below maintenance) — not a crash diet.'
    ),
    (
      Icons.local_dining_rounded,
      'Eat protein at every meal. It protects the muscle you are training '
          'and keeps you full.'
    ),
    (
      Icons.trending_up_rounded,
      'Progress the weights: when every set hits the top of the rep range '
          'with good form, go up one step next time.'
    ),
    (
      Icons.directions_walk_rounded,
      'On rest days, walk. 7–10k steps a day adds up to more than any '
          'single workout.'
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        children: [
          for (final (icon, text) in _notes)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 7),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(icon, size: 22, color: AppColors.accent),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(text,
                        style: const TextStyle(
                            height: 1.4, color: AppColors.textDim)),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
