import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../state/history_controller.dart';
import '../state/profile_controller.dart';
import '../state/session_controller.dart';
import '../theme.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import '../widgets/rest_timer_panel.dart';
import '../widgets/set_tracker_card.dart';
import 'summary_screen.dart';

class WorkoutScreen extends StatefulWidget {
  const WorkoutScreen({super.key});

  @override
  State<WorkoutScreen> createState() => _WorkoutScreenState();
}

class _WorkoutScreenState extends State<WorkoutScreen> {
  @override
  void initState() {
    super.initState();
    // Optional: keep the display on. Timers are accurate either way.
    if (context.read<ProfileController>().keepScreenOn) {
      WakelockPlus.enable();
    }
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<SessionController>();
    if (!s.isActive) {
      // Briefly visible while navigating away after finishing.
      return const Scaffold(body: SizedBox.shrink());
    }
    final d = s.day!;

    return Scaffold(
      appBar: AppBar(
        title: Text('Day ${d.id} · ${d.title}',
            overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            tooltip: s.isPaused ? 'Resume' : 'Pause',
            iconSize: 32,
            onPressed: s.isPaused ? s.resume : s.pause,
            icon: Icon(
                s.isPaused ? Icons.play_arrow_rounded : Icons.pause_rounded),
          ),
          IconButton(
            tooltip: 'End workout',
            iconSize: 30,
            onPressed: () => _confirmEnd(context, s),
            icon: const Icon(Icons.stop_circle_outlined),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        color: s.restJustEnded ? d.color.withAlpha(46) : AppColors.bg,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
          children: [
            _HeaderStats(s: s, color: d.color),
            if (s.isPaused) ...[
              const SizedBox(height: 12),
              _PausedBanner(onResume: s.resume),
            ],
            const SizedBox(height: 12),
            if (s.isResting) ...[
              RestTimerPanel(s: s),
              const SizedBox(height: 12),
            ],
            if (s.allDone)
              _FinishCard(color: d.color, onFinish: () => _finish(context, s))
            else
              SetTrackerCard(s: s, index: s.currentIndex),
            const SectionLabel('Workout plan'),
            for (var i = 0; i < d.exercises.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: _PlanRow(s: s, index: i),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _finish(BuildContext context, SessionController s) async {
    final history = context.read<HistoryController>();
    final nav = Navigator.of(context);
    final log = s.buildLog();
    await history.add(log);
    nav.pushReplacement(
        MaterialPageRoute(builder: (_) => SummaryScreen(log: log)));
    s.end();
  }

  Future<void> _confirmEnd(BuildContext context, SessionController s) async {
    final choice = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surfaceHigh,
        title: const Text('End workout?'),
        content: Text(
          '${s.progressPct}% complete · ~${s.kcal.round()} kcal so far.\n'
          'Save it to your history, or discard it.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, 'discard'),
            child: const Text('Discard',
                style: TextStyle(color: AppColors.hot)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Keep going'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, 'save'),
            child: const Text('Save',
                style: TextStyle(
                    color: AppColors.accent, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
    if (!context.mounted) return;
    if (choice == 'save') {
      await _finish(context, s);
    } else if (choice == 'discard') {
      Navigator.of(context).pop();
      s.end();
    }
  }
}

class _HeaderStats extends StatelessWidget {
  const _HeaderStats({required this.s, required this.color});
  final SessionController s;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Row(
        children: [
          ProgressRing(
            value: s.progress,
            size: 108,
            stroke: 11,
            color: color,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('${s.progressPct}%',
                    style: const TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.w900,
                        fontFeatures: tabular)),
                const Text('done',
                    style: TextStyle(fontSize: 12, color: AppColors.textDim)),
              ],
            ),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              children: [
                _Metric(
                  icon: Icons.timer_outlined,
                  label: 'Time',
                  value: fmtClock(s.elapsedSec),
                ),
                const SizedBox(height: 12),
                _Metric(
                  icon: Icons.local_fire_department_rounded,
                  label: 'Burned',
                  value: '${s.kcal.round()} kcal',
                  color: AppColors.hot,
                ),
                const SizedBox(height: 12),
                _Metric(
                  icon: Icons.check_circle_outline_rounded,
                  label: 'Sets',
                  value: '${s.totalDoneSets} / ${s.day!.totalSets}',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({
    required this.icon,
    required this.label,
    required this.value,
    this.color = AppColors.textDim,
  });

  final IconData icon;
  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 20, color: color),
        const SizedBox(width: 8),
        Text(label, style: const TextStyle(color: AppColors.textDim)),
        const Spacer(),
        Text(
          value,
          style: const TextStyle(
              fontSize: 18, fontWeight: FontWeight.w800, fontFeatures: tabular),
        ),
      ],
    );
  }
}

class _PausedBanner extends StatelessWidget {
  const _PausedBanner({required this.onResume});
  final VoidCallback onResume;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      color: AppColors.surfaceHigh,
      padding: const EdgeInsets.fromLTRB(18, 10, 10, 10),
      child: Row(
        children: [
          const Icon(Icons.pause_circle_filled_rounded,
              color: AppColors.textDim),
          const SizedBox(width: 10),
          const Expanded(
            child: Text('Paused — timers are frozen',
                style: TextStyle(fontWeight: FontWeight.w600)),
          ),
          TextButton(
            onPressed: onResume,
            child: const Text('RESUME',
                style: TextStyle(
                    color: AppColors.accent, fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }
}

class _FinishCard extends StatelessWidget {
  const _FinishCard({required this.color, required this.onFinish});
  final Color color;
  final VoidCallback onFinish;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      borderColor: color.withAlpha(140),
      child: Column(
        children: [
          Icon(Icons.emoji_events_rounded, size: 56, color: color),
          const SizedBox(height: 10),
          const Text('All sets done!',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          const Text(
            'Great work. Save the session to log it.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.textDim),
          ),
          const SizedBox(height: 18),
          BigButton(
            label: 'FINISH & SAVE',
            icon: Icons.flag_rounded,
            color: color,
            onPressed: onFinish,
          ),
        ],
      ),
    );
  }
}

class _PlanRow extends StatelessWidget {
  const _PlanRow({required this.s, required this.index});
  final SessionController s;
  final int index;

  @override
  Widget build(BuildContext context) {
    final d = s.day!;
    final e = d.exercises[index];
    final done = s.doneSets(index);
    final finished = done >= e.sets;
    final current = index == s.currentIndex && !s.allDone;

    return AppCard(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      color: current ? AppColors.surfaceHigh : AppColors.surface,
      borderColor: current ? d.color : null,
      onTap: s.anyWorking ? null : () => s.selectExercise(index),
      child: Row(
        children: [
          Icon(
            finished
                ? Icons.check_circle_rounded
                : current
                    ? Icons.radio_button_checked_rounded
                    : Icons.radio_button_unchecked_rounded,
            color: finished || current ? d.color : AppColors.textDim,
            size: 26,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  e.name,
                  style: TextStyle(
                    fontSize: 15.5,
                    fontWeight: FontWeight.w700,
                    color: finished ? AppColors.textDim : AppColors.text,
                  ),
                ),
                Text(e.prescription,
                    style: const TextStyle(
                        fontSize: 13, color: AppColors.textDim)),
              ],
            ),
          ),
          Text(
            '$done/${e.sets}',
            style: const TextStyle(
                fontWeight: FontWeight.w800, fontFeatures: tabular),
          ),
        ],
      ),
    );
  }
}
