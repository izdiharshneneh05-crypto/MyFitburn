/// Formatting helpers shared across screens.
library;

/// `75` → `1:15`, `3725` → `1:02:05`.
String fmtClock(int totalSec) {
  final s = totalSec < 0 ? 0 : totalSec;
  final h = s ~/ 3600;
  final m = (s % 3600) ~/ 60;
  final sec = s % 60;
  String two(int v) => v.toString().padLeft(2, '0');
  return h > 0 ? '$h:${two(m)}:${two(sec)}' : '$m:${two(sec)}';
}

/// `30` → `30 s`, `90` → `1 min 30 s`, `1200` → `20 min`.
String fmtDur(int sec) {
  if (sec < 60) return '$sec s';
  final m = sec ~/ 60;
  final s = sec % 60;
  return s == 0 ? '$m min' : '$m min $s s';
}
