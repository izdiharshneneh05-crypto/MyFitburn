import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/models.dart';

class HistoryController extends ChangeNotifier {
  HistoryController(this._prefs) {
    _load();
  }

  static const _key = 'workout_history_v1';
  static const _maxEntries = 300;

  final SharedPreferences _prefs;
  List<WorkoutLog> _logs = [];

  /// Newest first.
  List<WorkoutLog> get logs => List.unmodifiable(_logs);

  void _load() {
    final raw = _prefs.getStringList(_key) ?? const [];
    _logs = raw
        .map((s) {
          try {
            return WorkoutLog.fromJson(jsonDecode(s) as Map<String, dynamic>);
          } catch (_) {
            return null;
          }
        })
        .whereType<WorkoutLog>()
        .toList();
  }

  Future<void> add(WorkoutLog log) async {
    _logs.insert(0, log);
    if (_logs.length > _maxEntries) _logs = _logs.sublist(0, _maxEntries);
    await _prefs.setStringList(
        _key, _logs.map((l) => jsonEncode(l.toJson())).toList());
    notifyListeners();
  }

  /// Weeks start on Monday.
  DateTime get _weekStart {
    final n = DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    return DateTime(today.year, today.month, today.day - (today.weekday - 1));
  }

  List<WorkoutLog> get thisWeek {
    final start = _weekStart;
    return _logs.where((l) => !l.date.isBefore(start)).toList();
  }

  bool doneThisWeek(int dayId) => thisWeek.any((l) => l.dayId == dayId);

  int get daysDoneThisWeek => thisWeek.map((l) => l.dayId).toSet().length;

  double get kcalThisWeek => thisWeek.fold(0.0, (s, l) => s + l.kcal);

  int get minutesThisWeek =>
      thisWeek.fold<int>(0, (s, l) => s + l.durationSec) ~/ 60;

  /// Cycle 1 → 2 → 3 → 4 → 1 based on the last workout done.
  int get recommendedDayId => _logs.isEmpty ? 1 : _logs.first.dayId % 4 + 1;
}
