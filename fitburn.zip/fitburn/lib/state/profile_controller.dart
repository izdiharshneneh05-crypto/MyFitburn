import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfileController extends ChangeNotifier {
  ProfileController(this._prefs);

  static const double kgPerLb = 0.45359237;
  static const _weightKey = 'weight_kg';
  static const _lbsKey = 'use_lbs';
  static const _screenKey = 'keep_screen_on';

  final SharedPreferences _prefs;

  /// Defaults to 80 kg until the user sets their weight.
  double get weightKg => _prefs.getDouble(_weightKey) ?? 80;
  bool get hasWeight => _prefs.containsKey(_weightKey);
  bool get useLbs => _prefs.getBool(_lbsKey) ?? false;
  bool get keepScreenOn => _prefs.getBool(_screenKey) ?? true;

  double get displayWeight => useLbs ? weightKg / kgPerLb : weightKg;
  String get weightUnit => useLbs ? 'lb' : 'kg';

  Future<void> setWeightKg(double kg) async {
    await _prefs.setDouble(_weightKey, kg);
    notifyListeners();
  }

  Future<void> setUseLbs(bool v) async {
    await _prefs.setBool(_lbsKey, v);
    notifyListeners();
  }

  Future<void> setKeepScreenOn(bool v) async {
    await _prefs.setBool(_screenKey, v);
    notifyListeners();
  }
}
