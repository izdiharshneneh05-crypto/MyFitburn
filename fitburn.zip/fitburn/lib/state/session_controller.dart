import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/plan.dart';
import '../models/models.dart';
import '../services/calories.dart';
import '../services/notification_service.dart';
import '../utils/format.dart';
import 'profile_controller.dart';

enum PhaseType { work, rest }

/// A running timer: a timed set ([PhaseType.work]) or a rest period.
/// Stored as absolute timestamps, never as a ticking counter.
class Phase {
  Phase({
    required this.type,
    required this.exerciseIndex,
    required this.startMs,
    required this.endMs,
  });

  final PhaseType type;
  final int exerciseIndex;
  int startMs;
  int endMs;

  int get totalMs => endMs - startMs;

  Map<String, dynamic> toJson() => {
        'type': type.name,
        'ex': exerciseIndex,
        'start': startMs,
        'end': endMs,
      };

  factory Phase.fromJson(Map<String, dynamic> j) => Phase(
        type: PhaseType.values.byName(j['type'] as String),
        exerciseIndex: j['ex'] as int,
        startMs: j['start'] as int,
        endMs: j['end'] as int,
      );
}

/// Owns the active workout.
///
/// Background accuracy rules:
/// 1. All time is derived from wall-clock timestamps, so suspension, a locked
///    screen or a killed process never makes the timer drift.
/// 2. Every alert is scheduled with Android's AlarmManager, so it fires even
///    if this code isn't running.
/// 3. State is persisted on every change and reconciled on resume/restart,
///    including timed sets and rests that finished while the app was away.
class SessionController extends ChangeNotifier with WidgetsBindingObserver {
  SessionController(this._prefs, this._profile) {
    WidgetsBinding.instance.addObserver(this);
    _restore();
  }

  static const _storeKey = 'active_session_v1';
  static const _restAlertId = 1;
  static const _workAlertId = 2;
  static const _statusId = 10;
  static const _maxSessionAge = Duration(hours: 12);

  final SharedPreferences _prefs;
  final ProfileController _profile;
  final NotificationService _notifications = NotificationService.instance;

  WorkoutDay? _day;
  int _startedAtMs = 0;
  int _pausedTotalMs = 0;
  int? _pausedAtMs;
  Phase? _phase;
  List<List<int>> _logged = []; // per exercise: reps (or seconds) per set
  List<int> _restMs = []; // per exercise: time actually spent resting
  int _currentIndex = 0;
  final Map<int, int> _repDraft = {};

  Timer? _ticker;
  bool _foreground = true;
  int _lastCue = -1;
  int _restEndedAtMs = 0;
  String _lastUiKey = '';

  int get _now => DateTime.now().millisecondsSinceEpoch;
  int get _clockMs => _pausedAtMs ?? _now;

  // ---------------------------------------------------------------- reading

  bool get isActive => _day != null;
  WorkoutDay? get day => _day;
  bool get isPaused => _pausedAtMs != null;
  Phase? get phase => _phase;
  int get currentIndex => _currentIndex;

  bool get isResting => _phase?.type == PhaseType.rest;
  bool get anyWorking => _phase?.type == PhaseType.work;
  bool isWorking(int i) => anyWorking && _phase!.exerciseIndex == i;

  /// True for ~1.5 s after a rest ends in the foreground (screen flash).
  bool get restJustEnded => _now - _restEndedAtMs < 1500;

  int get elapsedSec =>
      math.max(0, (_clockMs - _startedAtMs - _pausedTotalMs) ~/ 1000);

  int get phaseRemainingMs =>
      _phase == null ? 0 : math.max(0, _phase!.endMs - _clockMs);

  int get phaseRemainingSec => (phaseRemainingMs / 1000).ceil();

  double get phaseProgress {
    final p = _phase;
    if (p == null || p.totalMs <= 0) return 0;
    return (1 - phaseRemainingMs / p.totalMs).clamp(0.0, 1.0);
  }

  int doneSets(int i) => _logged[i].length;
  List<int> loggedFor(int i) => List.unmodifiable(_logged[i]);
  bool isExerciseDone(int i) => _logged[i].length >= _day!.exercises[i].sets;
  int get totalDoneSets => _logged.fold<int>(0, (s, l) => s + l.length);
  bool get allDone => isActive && totalDoneSets >= _day!.totalSets;

  /// Rep count shown in the stepper: last logged value, else the target.
  int repDraft(int i) {
    final e = _day!.exercises[i];
    if (_repDraft[i] != null) return _repDraft[i]!;
    if (!e.isTimed && _logged[i].isNotEmpty) return _logged[i].last;
    return e.reps ?? 0;
  }

  /// Time-weighted completion: each set counts as its work time plus the
  /// rest that follows, so a 20-minute walk weighs more than a set of curls.
  double get progress {
    final d = _day;
    if (d == null) return 0;
    if (allDone) return 1;
    var total = 0;
    var done = 0.0;
    for (var i = 0; i < d.exercises.length; i++) {
      final e = d.exercises[i];
      total += e.sets * e.plannedSetSec;
      done += math.min(_logged[i].length, e.sets) * e.plannedSetSec;
    }
    final p = _phase;
    if (p != null && p.type == PhaseType.work) {
      final e = d.exercises[p.exerciseIndex];
      final sec = math.max(0, _clockMs - p.startMs) / 1000;
      done += math.min(e.plannedWorkSec.toDouble(), sec);
    }
    return total == 0 ? 0 : (done / total).clamp(0.0, 1.0);
  }

  int get progressPct => (progress * 100).round();

  /// Live calorie estimate: logged work at each exercise's MET, rests at the
  /// exercise's rest MET, everything else (setup, walking around) at idle MET.
  double get kcal {
    final d = _day;
    if (d == null) return 0;
    final kg = _profile.weightKg;
    var total = 0.0;
    var accounted = 0.0;
    for (var i = 0; i < d.exercises.length; i++) {
      final e = d.exercises[i];
      for (final v in _logged[i]) {
        final sec = (e.isTimed ? v : e.repWorkSec(v)).toDouble();
        total += Calories.fromMet(e.met, sec, kg);
        accounted += sec;
      }
      final restSec = _restMs[i] / 1000;
      total += Calories.fromMet(e.restMet, restSec, kg);
      accounted += restSec;
    }
    final p = _phase;
    if (p != null) {
      final e = d.exercises[p.exerciseIndex];
      final sec = math.max(0, _clockMs - p.startMs) / 1000;
      total += Calories.fromMet(
          p.type == PhaseType.work ? e.met : e.restMet, sec, kg);
      accounted += sec;
    }
    final idle = math.max(0.0, elapsedSec - accounted);
    return total + Calories.fromMet(Calories.idleMet, idle, kg);
  }

  String get nextUpLabel {
    final d = _day;
    if (d == null) return '';
    if (allDone) return 'Workout complete';
    final e = d.exercises[_currentIndex];
    return '${e.name} · set ${doneSets(_currentIndex) + 1} of ${e.sets}';
  }

  // ---------------------------------------------------------------- actions

  Future<void> start(WorkoutDay d) async {
    _clear();
    _day = d;
    _startedAtMs = _now;
    _pausedTotalMs = 0;
    _pausedAtMs = null;
    _phase = null;
    _logged = List.generate(d.exercises.length, (_) => <int>[]);
    _restMs = List.filled(d.exercises.length, 0);
    _currentIndex = 0;
    _repDraft.clear();
    _startTicker();
    _commit();
  }

  void selectExercise(int i) {
    if (!isActive || anyWorking) return;
    _currentIndex = i;
    _commit();
  }

  void adjustReps(int i, int delta) {
    if (!isActive) return;
    _repDraft[i] = (repDraft(i) + delta).clamp(0, 99);
    if (_foreground) HapticFeedback.selectionClick();
    notifyListeners();
  }

  /// Logs a set. For timed exercises this logs the full planned duration
  /// (for when you did it without the in-app timer).
  void completeSet(int i) {
    if (!_canAct || anyWorking || isExerciseDone(i)) return;
    final e = _day!.exercises[i];
    _logSet(i, e.isTimed ? e.durationSec! : repDraft(i), atMs: _now);
  }

  void startTimedSet(int i) {
    if (!_canAct || anyWorking || isExerciseDone(i)) return;
    final e = _day!.exercises[i];
    if (!e.isTimed) return;
    final now = _now;
    _endRest(now, cancelAlert: true);
    _currentIndex = i;
    _phase = Phase(
      type: PhaseType.work,
      exerciseIndex: i,
      startMs: now,
      endMs: now + e.durationSec! * 1000,
    );
    _lastCue = -1;
    _scheduleAlertsForPhase();
    if (_foreground) HapticFeedback.mediumImpact();
    _commit();
  }

  void finishTimedSetEarly() {
    final p = _phase;
    if (!_canAct || p == null || p.type != PhaseType.work) return;
    _notifications.cancel(_workAlertId);
    _notifications.cancel(_restAlertId);
    _completeWork(p, atMs: _now);
  }

  void cancelTimedSet() {
    if (!anyWorking) return;
    _notifications.cancel(_workAlertId);
    _notifications.cancel(_restAlertId);
    _phase = null;
    _commit();
  }

  void skipRest() {
    if (!isResting) return;
    _endRest(_clockMs, cancelAlert: true);
    _commit();
  }

  void extendRest(int seconds) {
    final p = _phase;
    if (!_canAct || p == null || p.type != PhaseType.rest) return;
    p.endMs = math.max(p.endMs, _now) + seconds * 1000;
    _lastCue = -1;
    _scheduleAlertsForPhase();
    _commit();
  }

  void undoLastSet(int i) {
    if (!isActive || anyWorking || _logged[i].isEmpty) return;
    if (isResting) _endRest(_clockMs, cancelAlert: true);
    _logged[i].removeLast();
    _repDraft.remove(i);
    _currentIndex = i;
    _commit();
  }

  void pause() {
    if (!_canAct) return;
    _pausedAtMs = _now;
    _notifications.cancel(_restAlertId);
    _notifications.cancel(_workAlertId);
    _commit();
  }

  void resume() {
    final at = _pausedAtMs;
    if (!isActive || at == null) return;
    final pausedFor = _now - at;
    _pausedTotalMs += pausedFor;
    final p = _phase;
    if (p != null) {
      // Freeze-and-shift: the timer continues exactly where it stopped.
      p.startMs += pausedFor;
      p.endMs += pausedFor;
    }
    _pausedAtMs = null;
    _scheduleAlertsForPhase();
    _commit();
  }

  /// Builds the log for the current session without ending it.
  WorkoutLog buildLog() {
    final d = _day!;
    return WorkoutLog(
      dayId: d.id,
      dayTitle: d.title,
      date: DateTime.fromMillisecondsSinceEpoch(_startedAtMs),
      durationSec: elapsedSec,
      kcal: kcal,
      setsDone: totalDoneSets,
      totalSets: d.totalSets,
    );
  }

  /// Ends the session and removes its notifications.
  void end() => _clear();

  // --------------------------------------------------------------- internals

  bool get _canAct => isActive && !isPaused;

  void _logSet(int i, int value, {required int atMs}) {
    final e = _day!.exercises[i];
    _endRest(atMs, cancelAlert: true);
    _logged[i].add(value);
    _repDraft.remove(i);
    _currentIndex = isExerciseDone(i) ? (_nextUnfinished(i) ?? i) : i;

    if (!allDone && e.restSec > 0) {
      // Rest starts when the set ended — even if that was minutes ago while
      // the app was in the background.
      _phase = Phase(
        type: PhaseType.rest,
        exerciseIndex: i,
        startMs: atMs,
        endMs: atMs + e.restSec * 1000,
      );
      _lastCue = -1;
      _scheduleAlertsForPhase();
    } else {
      _phase = null;
    }
    if (_foreground) HapticFeedback.mediumImpact();
    _commit();
  }

  void _completeWork(Phase p, {required int atMs}) {
    _phase = null;
    final sec = ((atMs - p.startMs) / 1000).round();
    _logSet(p.exerciseIndex, sec, atMs: atMs);
  }

  void _endRest(int atMs, {required bool cancelAlert}) {
    final p = _phase;
    if (p == null || p.type != PhaseType.rest) return;
    _restMs[p.exerciseIndex] +=
        math.max(0, math.min(atMs, p.endMs) - p.startMs);
    _phase = null;
    // On a natural finish the alert has already rung — cancelling it would
    // pull it out of the notification shade, so only cancel when cut short.
    if (cancelAlert) _notifications.cancel(_restAlertId);
  }

  int? _nextUnfinished(int from, {int? assumeDone}) {
    final n = _day!.exercises.length;
    for (var k = 1; k <= n; k++) {
      final j = (from + k) % n;
      if (j == assumeDone) continue;
      if (!isExerciseDone(j)) return j;
    }
    return null;
  }

  /// What comes after one more set of exercise [i] is logged.
  String _labelAfterNextSet(int i) {
    final d = _day!;
    final e = d.exercises[i];
    final after = doneSets(i) + 1;
    if (after < e.sets) return '${e.name} · set ${after + 1} of ${e.sets}';
    final n = _nextUnfinished(i, assumeDone: i);
    if (n == null) return 'Finish your workout';
    final ne = d.exercises[n];
    return '${ne.name} · set ${doneSets(n) + 1} of ${ne.sets}';
  }

  void _scheduleAlertsForPhase() {
    final p = _phase;
    if (p == null || isPaused) return;
    final d = _day!;
    final e = d.exercises[p.exerciseIndex];

    if (p.type == PhaseType.rest) {
      _notifications.scheduleAlert(
        id: _restAlertId,
        atMs: p.endMs,
        title: "Rest's over — let's go! 💪",
        body: 'Next: $nextUpLabel',
      );
      return;
    }

    final isLastSetOfWorkout = d.totalSets - totalDoneSets <= 1;
    final next = _labelAfterNextSet(p.exerciseIndex);
    _notifications.scheduleAlert(
      id: _workAlertId,
      atMs: p.endMs,
      title: '${e.name}: set done ✅',
      body: isLastSetOfWorkout
          ? 'Last set finished. Open FitBurn to save your workout.'
          : e.restSec > 0
              ? 'Rest ${fmtDur(e.restSec)}. Next: $next'
              : 'Next: $next',
    );
    // Also pre-schedule the rest alert, so the full work → rest → go cycle
    // rings on time even if the app never wakes up in between.
    if (!isLastSetOfWorkout && e.restSec > 0) {
      _notifications.scheduleAlert(
        id: _restAlertId,
        atMs: p.endMs + e.restSec * 1000,
        title: "Rest's over — let's go! 💪",
        body: 'Next: $next',
      );
    }
  }

  void _startTicker() {
    _ticker?.cancel();
    _ticker =
        Timer.periodic(const Duration(milliseconds: 250), (_) => _tick());
  }

  /// Advances phases whose end time has passed, then refreshes the UI.
  /// Safe to call at any moment — e.g. after hours in the background.
  void _tick() {
    if (!isActive) return;
    if (!isPaused) {
      final now = _now;
      var p = _phase;
      if (p != null && p.type == PhaseType.work && now >= p.endMs) {
        _completeWork(p, atMs: p.endMs);
        p = _phase;
      }
      if (p != null && p.type == PhaseType.rest) {
        if (now >= p.endMs) {
          _endRest(p.endMs, cancelAlert: false);
          if (now - p.endMs < 2000) {
            _restEndedAtMs = now;
            if (_foreground) HapticFeedback.heavyImpact();
          }
          _commit();
        } else {
          final left = ((p.endMs - now) / 1000).ceil();
          if (left <= 3 && left != _lastCue) {
            _lastCue = left;
            if (_foreground) HapticFeedback.lightImpact();
          }
        }
      }
    }
    // Rebuild only when something visible changed.
    final key = '$elapsedSec|$phaseRemainingSec|${_phase?.type}|'
        '$restJustEnded|$isPaused';
    if (key != _lastUiKey) {
      _lastUiKey = key;
      notifyListeners();
    }
  }

  /// Persist, refresh the status notification and the UI.
  void _commit() {
    _persist();
    _syncStatus();
    notifyListeners();
  }

  void _syncStatus() {
    final d = _day;
    if (d == null) {
      _notifications.cancel(_statusId);
      return;
    }
    final p = _phase;
    if (isPaused) {
      _notifications.showStatus(
        id: _statusId,
        title: 'Workout paused',
        body: 'Day ${d.id} · ${d.title} · $progressPct% done',
      );
    } else if (p != null && p.type == PhaseType.rest) {
      _notifications.showStatus(
        id: _statusId,
        title: 'Resting',
        body: 'Next: $nextUpLabel',
        whenMs: p.endMs,
        countDown: true,
      );
    } else if (p != null && p.type == PhaseType.work) {
      final e = d.exercises[p.exerciseIndex];
      _notifications.showStatus(
        id: _statusId,
        title: e.name,
        body: 'Set ${doneSets(p.exerciseIndex) + 1} of ${e.sets} — keep going!',
        whenMs: p.endMs,
        countDown: true,
      );
    } else {
      _notifications.showStatus(
        id: _statusId,
        title: 'Day ${d.id} · ${d.title}',
        body: '$progressPct% done · ~${kcal.round()} kcal',
        whenMs: _startedAtMs + _pausedTotalMs,
      );
    }
  }

  void _persist() {
    final d = _day;
    if (d == null) return;
    _prefs.setString(
      _storeKey,
      jsonEncode({
        'day': d.id,
        'startedAt': _startedAtMs,
        'pausedTotal': _pausedTotalMs,
        'pausedAt': _pausedAtMs,
        'phase': _phase?.toJson(),
        'logged': _logged,
        'restMs': _restMs,
        'current': _currentIndex,
      }),
    );
  }

  void _restore() {
    final raw = _prefs.getString(_storeKey);
    if (raw == null) return;
    try {
      final j = jsonDecode(raw) as Map<String, dynamic>;
      final d = planDayById(j['day'] as int);
      final started = j['startedAt'] as int;
      final logged = (j['logged'] as List)
          .map((l) => (l as List).map((v) => v as int).toList())
          .toList();
      final restMs = (j['restMs'] as List).map((v) => v as int).toList();
      final stale = _now - started > _maxSessionAge.inMilliseconds;
      if (d == null ||
          stale ||
          logged.length != d.exercises.length ||
          restMs.length != d.exercises.length) {
        _clear();
        return;
      }
      _day = d;
      _startedAtMs = started;
      _pausedTotalMs = j['pausedTotal'] as int;
      _pausedAtMs = j['pausedAt'] as int?;
      _logged = logged;
      _restMs = restMs;
      _phase = j['phase'] == null
          ? null
          : Phase.fromJson(Map<String, dynamic>.from(j['phase'] as Map));
      _currentIndex = (j['current'] as int).clamp(0, d.exercises.length - 1);
      final state = WidgetsBinding.instance.lifecycleState;
      _foreground = state == null || state == AppLifecycleState.resumed;
      _startTicker();
      _tick(); // reconcile anything that finished while the app was dead
      _syncStatus();
    } catch (_) {
      _clear();
    }
  }

  void _clear() {
    _ticker?.cancel();
    _ticker = null;
    _day = null;
    _phase = null;
    _pausedAtMs = null;
    _logged = [];
    _restMs = [];
    _repDraft.clear();
    _prefs.remove(_storeKey);
    _notifications.cancel(_restAlertId);
    _notifications.cancel(_workAlertId);
    _notifications.cancel(_statusId);
    notifyListeners();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _foreground = state == AppLifecycleState.resumed;
    if (_foreground) _tick();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ticker?.cancel();
    super.dispose();
  }
}
