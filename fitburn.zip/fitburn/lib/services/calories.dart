/// Calorie estimation using the standard MET formula
/// (Compendium of Physical Activities):
///
///   kcal per minute = MET × 3.5 × body-weight-kg ÷ 200
///
/// MET values per exercise live in the workout plan. Time that is neither a
/// logged set nor a timed rest (setting up machines, walking between stations)
/// is counted at [idleMet]. Expect roughly ±25 % accuracy — good for trends,
/// not for exact bookkeeping.
class Calories {
  Calories._();

  /// Light activity: standing, walking around the gym floor.
  static const double idleMet = 2.5;

  static double fromMet(double met, double seconds, double weightKg) =>
      met * 3.5 * weightKg / 200.0 * (seconds / 60.0);
}
