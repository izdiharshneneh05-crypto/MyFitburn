import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

/// Why this design survives a locked screen or a killed app:
///
/// The timer is never a running countdown in Dart. A rest period is stored
/// as an absolute end time, and the alert is handed to Android's AlarmManager
/// via a scheduled notification. AlarmManager fires the alert even if our
/// process is suspended or dead. When the app returns, the UI recomputes
/// everything from timestamps, so it's always exact.
///
/// The "workout in progress" status notification uses Android's native
/// chronometer, so the countdown in the notification shade ticks with no
/// Dart code running at all.
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  static const _alertChannelId = 'fitburn_timer_alerts_v1';
  static const _alertChannelName = 'Timer alerts';
  static const _statusChannelId = 'fitburn_session_status_v1';
  static const _statusChannelName = 'Workout in progress';
  static const _askedExactKey = 'asked_exact_alarms_v1';

  static final Int64List _vibration =
      Int64List.fromList([0, 450, 200, 450, 200, 900]);

  AndroidFlutterLocalNotificationsPlugin? get _android =>
      _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  Future<void> init() async {
    tzdata.initializeTimeZones();
    const settings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(
        requestAlertPermission: false,
        requestBadgePermission: false,
        requestSoundPermission: false,
      ),
    );
    await _plugin.initialize(settings);

    // Create channels up front; their importance can't change later.
    await _android?.createNotificationChannel(AndroidNotificationChannel(
      _alertChannelId,
      _alertChannelName,
      description: 'Rings when a rest period or timed set ends.',
      importance: Importance.max,
      playSound: true,
      enableVibration: true,
      vibrationPattern: _vibration,
      audioAttributesUsage: AudioAttributesUsage.alarm,
    ));
    await _android?.createNotificationChannel(const AndroidNotificationChannel(
      _statusChannelId,
      _statusChannelName,
      description: 'Live workout status with a running timer.',
      importance: Importance.low,
      playSound: false,
      enableVibration: false,
      showBadge: false,
    ));
  }

  Future<void> ensurePermissions() async {
    await _android?.requestNotificationsPermission(); // Android 13+
    await _plugin
        .resolvePlatformSpecificImplementation<
            IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(alert: true, sound: true, badge: false);
  }

  /// Exact alarms ("Alarms & reminders") are off by default on Android 14+.
  /// We explain and ask once; without it alerts may arrive a little late.
  Future<bool> shouldAskExactAlarms() async {
    if (_android == null) return false;
    final prefs = await SharedPreferences.getInstance();
    return !(prefs.getBool(_askedExactKey) ?? false);
  }

  Future<void> markExactAlarmsAsked() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_askedExactKey, true);
  }

  Future<void> requestExactAlarms() async {
    await markExactAlarmsAsked();
    await _android?.requestExactAlarmsPermission();
  }

  /// Schedules a loud alert at [atMs] (epoch ms). Replaces any pending alert
  /// with the same [id]. Past times are ignored.
  Future<void> scheduleAlert({
    required int id,
    required int atMs,
    required String title,
    required String body,
  }) async {
    final at = DateTime.fromMillisecondsSinceEpoch(atMs);
    if (!at.isAfter(DateTime.now().add(const Duration(milliseconds: 300)))) {
      return;
    }
    final when = tz.TZDateTime.from(at, tz.UTC);
    final details = NotificationDetails(
      android: AndroidNotificationDetails(
        _alertChannelId,
        _alertChannelName,
        importance: Importance.max,
        priority: Priority.high,
        category: AndroidNotificationCategory.alarm,
        playSound: true,
        enableVibration: true,
        vibrationPattern: _vibration,
        audioAttributesUsage: AudioAttributesUsage.alarm,
        visibility: NotificationVisibility.public,
        ticker: title,
        timeoutAfter: 60000,
      ),
      iOS: const DarwinNotificationDetails(
        presentAlert: true,
        presentSound: true,
        interruptionLevel: InterruptionLevel.timeSensitive,
      ),
    );

    // alarmClock mode is the most reliable: it's exempt from Doze batching,
    // so the alert fires on the second. If exact alarms aren't permitted,
    // fall back to an inexact alarm rather than failing.
    try {
      await _zoned(id, title, body, when, details,
          AndroidScheduleMode.alarmClock);
    } on PlatformException {
      await _zoned(id, title, body, when, details,
          AndroidScheduleMode.inexactAllowWhileIdle);
    }
  }

  Future<void> _zoned(int id, String title, String body, tz.TZDateTime when,
      NotificationDetails details, AndroidScheduleMode mode) {
    return _plugin.zonedSchedule(
      id,
      title,
      body,
      when,
      details,
      androidScheduleMode: mode,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  /// Silent, sticky status notification. With [whenMs] set, Android renders
  /// a live chronometer (counting up, or down when [countDown] is true).
  Future<void> showStatus({
    required int id,
    required String title,
    required String body,
    int? whenMs,
    bool countDown = false,
  }) async {
    if (_android == null) return; // ongoing notifications are Android-only
    final details = NotificationDetails(
      android: AndroidNotificationDetails(
        _statusChannelId,
        _statusChannelName,
        importance: Importance.low,
        priority: Priority.low,
        ongoing: true,
        autoCancel: false,
        onlyAlertOnce: true,
        silent: true,
        showWhen: whenMs != null,
        when: whenMs,
        usesChronometer: whenMs != null,
        chronometerCountDown: countDown,
        visibility: NotificationVisibility.public,
      ),
    );
    await _plugin.show(id, title, body, details);
  }

  Future<void> cancel(int id) => _plugin.cancel(id);
}
