import 'package:flutter/painting.dart' show Color;

import '../models/models.dart';

/// The 4-day fat-loss split.
///
/// Coaching logic:
/// * Every day pairs resistance work (keeps muscle while in a calorie
///   deficit) with treadmill cardio (extra energy expenditure).
/// * Moderate reps (10–15) with short rests (30–75 s) keep the heart rate up.
/// * Compound lifts first while fresh, isolation after, cardio last so it
///   doesn't sap strength.
/// * Progression: when you hit the top of the rep range on every set with
///   good form, add the smallest weight increment next session.
///
/// MET values are conservative Compendium-based estimates.
const List<WorkoutDay> workoutPlan = [
  WorkoutDay(
    id: 1,
    title: 'Upper Body + Incline Walk',
    focus: 'Back, chest, shoulders · steady cardio',
    summary:
        'Big upper-body pulls and presses, then a 20-minute incline walk — '
        'one of the most effective low-impact fat burners there is.',
    color: Color(0xFFC6FF3D),
    exercises: [
      Exercise(
        id: 'd1-warmup',
        name: 'Treadmill Warm-up',
        equipment: Equipment.treadmill,
        sets: 1,
        durationSec: 300,
        restSec: 60,
        met: 4.3,
        setting: '5.5 km/h · 1% incline',
        cue: 'Easy pace, relaxed shoulders. You should be able to talk freely.',
      ),
      Exercise(
        id: 'd1-pulldown',
        name: 'Lat Pulldown',
        equipment: Equipment.machine,
        sets: 3,
        reps: 12,
        restSec: 60,
        met: 5.0,
        cue: 'Pull the bar to your upper chest, elbows down and back. '
            'Only a slight lean back.',
      ),
      Exercise(
        id: 'd1-db-bench',
        name: 'Dumbbell Bench Press',
        equipment: Equipment.dumbbell,
        sets: 3,
        reps: 10,
        restSec: 75,
        met: 6.0,
        cue: 'Lower for 2 seconds to chest level, press up and slightly in. '
            'Feet flat, shoulder blades pinched.',
      ),
      Exercise(
        id: 'd1-row',
        name: 'Seated Cable Row',
        equipment: Equipment.machine,
        sets: 3,
        reps: 12,
        restSec: 60,
        met: 5.0,
        cue: 'Chest tall. Squeeze your shoulder blades together at the end '
            'of every pull.',
      ),
      Exercise(
        id: 'd1-ohp',
        name: 'Seated Dumbbell Shoulder Press',
        equipment: Equipment.dumbbell,
        sets: 3,
        reps: 10,
        restSec: 60,
        met: 5.0,
        cue: 'Brace your core and press overhead without arching your '
            'lower back.',
      ),
      Exercise(
        id: 'd1-lateral',
        name: 'Dumbbell Lateral Raise',
        equipment: Equipment.dumbbell,
        sets: 3,
        reps: 15,
        restSec: 45,
        met: 4.0,
        cue: 'Light weight. Raise to shoulder height, leading with the '
            'elbows. No swinging.',
      ),
      Exercise(
        id: 'd1-incline',
        name: 'Incline Treadmill Walk',
        equipment: Equipment.treadmill,
        sets: 1,
        durationSec: 1200,
        restSec: 0,
        met: 5.3,
        setting: '5.0 km/h · 10–12% incline',
        cue: "Don't hold the rails — holding on cuts the calorie burn "
            'sharply. Slow down instead of grabbing.',
      ),
    ],
  ),
  WorkoutDay(
    id: 2,
    title: 'Lower Body + Core',
    focus: 'Legs, glutes, core',
    summary:
        'Your legs are your biggest muscles, so this is the highest-burn '
        'lifting day. Finish with core work and an easy cool-down walk.',
    color: Color(0xFFFF8A3D),
    exercises: [
      Exercise(
        id: 'd2-warmup',
        name: 'Treadmill Warm-up',
        equipment: Equipment.treadmill,
        sets: 1,
        durationSec: 300,
        restSec: 60,
        met: 4.3,
        setting: '5.5 km/h · 3% incline',
        cue: 'Gradually raise the pace. Loosen up hips and ankles.',
      ),
      Exercise(
        id: 'd2-goblet',
        name: 'Goblet Squat',
        equipment: Equipment.dumbbell,
        sets: 3,
        reps: 12,
        restSec: 75,
        met: 6.0,
        cue: 'Hold the dumbbell at your chest. Sit between your heels, '
            'chest up, knees track over toes.',
      ),
      Exercise(
        id: 'd2-legpress',
        name: 'Leg Press',
        equipment: Equipment.machine,
        sets: 3,
        reps: 12,
        restSec: 75,
        met: 6.0,
        cue: 'Feet shoulder-width. Lower until knees reach ~90°. '
            "Don't lock your knees at the top.",
      ),
      Exercise(
        id: 'd2-rdl',
        name: 'Dumbbell Romanian Deadlift',
        equipment: Equipment.dumbbell,
        sets: 3,
        reps: 10,
        restSec: 75,
        met: 6.0,
        cue: 'Hinge at the hips with soft knees. Dumbbells slide down your '
            'thighs. Flat back, feel the hamstrings stretch.',
      ),
      Exercise(
        id: 'd2-lunge',
        name: 'Dumbbell Walking Lunge',
        equipment: Equipment.dumbbell,
        sets: 3,
        reps: 10,
        perSide: true,
        restSec: 60,
        met: 6.0,
        cue: 'Long step, back knee almost touches the floor, push through '
            'the front heel.',
      ),
      Exercise(
        id: 'd2-legcurl',
        name: 'Lying Leg Curl',
        equipment: Equipment.machine,
        sets: 3,
        reps: 12,
        restSec: 60,
        met: 4.0,
        cue: 'Curl smoothly, pause at the top, lower for 2–3 seconds.',
      ),
      Exercise(
        id: 'd2-plank',
        name: 'Plank',
        equipment: Equipment.bodyweight,
        sets: 3,
        durationSec: 45,
        restSec: 30,
        met: 3.8,
        cue: 'Elbows under shoulders, squeeze glutes, straight line from '
            'head to heels.',
      ),
      Exercise(
        id: 'd2-cablecrunch',
        name: 'Cable Crunch',
        equipment: Equipment.machine,
        sets: 3,
        reps: 15,
        restSec: 30,
        met: 4.0,
        cue: 'Kneel, rope by your head. Crunch your ribs toward your hips — '
            "don't pull with your arms.",
      ),
      Exercise(
        id: 'd2-cooldown',
        name: 'Cool-down Walk',
        equipment: Equipment.treadmill,
        sets: 1,
        durationSec: 480,
        restSec: 0,
        met: 3.5,
        setting: '4.5–5.0 km/h · 2% incline',
        cue: 'Easy walk to bring your heart rate down.',
      ),
    ],
  ),
  WorkoutDay(
    id: 3,
    title: 'Push / Pull + Zone 2 Jog',
    focus: 'Alternating push & pull · steady jog',
    summary:
        'Pressing and pulling exercises alternate, so one side recovers while '
        'the other works — shorter rests, higher heart rate. Then a '
        'conversational-pace jog.',
    color: Color(0xFF3DD9FF),
    exercises: [
      Exercise(
        id: 'd3-warmup',
        name: 'Treadmill Warm-up',
        equipment: Equipment.treadmill,
        sets: 1,
        durationSec: 300,
        restSec: 60,
        met: 4.3,
        setting: '5.5 km/h · 1% incline',
        cue: 'Easy pace. Roll your shoulders and swing your arms.',
      ),
      Exercise(
        id: 'd3-chestpress',
        name: 'Machine Chest Press',
        equipment: Equipment.machine,
        sets: 3,
        reps: 12,
        restSec: 45,
        met: 5.0,
        cue: 'Handles at mid-chest. Press out smoothly, control the return.',
      ),
      Exercise(
        id: 'd3-pullup',
        name: 'Assisted Pull-up',
        equipment: Equipment.machine,
        sets: 3,
        reps: 8,
        restSec: 60,
        met: 5.5,
        cue: 'Use enough assistance to get clean reps. Chin over the bar, '
            'full hang at the bottom.',
      ),
      Exercise(
        id: 'd3-incline',
        name: 'Incline Dumbbell Press',
        equipment: Equipment.dumbbell,
        sets: 3,
        reps: 10,
        restSec: 60,
        met: 5.5,
        cue: 'Bench at 30°. Lower to upper chest, press up over your eyes.',
      ),
      Exercise(
        id: 'd3-row',
        name: 'One-arm Dumbbell Row',
        equipment: Equipment.dumbbell,
        sets: 3,
        reps: 10,
        perSide: true,
        restSec: 45,
        met: 5.0,
        cue: 'Hand and knee on the bench. Pull the dumbbell to your hip, '
            'not your chest.',
      ),
      Exercise(
        id: 'd3-pushdown',
        name: 'Cable Triceps Pushdown',
        equipment: Equipment.machine,
        sets: 3,
        reps: 12,
        restSec: 45,
        met: 4.0,
        cue: 'Elbows pinned to your sides. Fully straighten, slow return.',
      ),
      Exercise(
        id: 'd3-hammer',
        name: 'Dumbbell Hammer Curl',
        equipment: Equipment.dumbbell,
        sets: 3,
        reps: 12,
        restSec: 45,
        met: 4.0,
        cue: 'Palms facing each other. No swinging — keep elbows still.',
      ),
      Exercise(
        id: 'd3-jog',
        name: 'Zone 2 Jog',
        equipment: Equipment.treadmill,
        sets: 1,
        durationSec: 900,
        restSec: 0,
        met: 6.5,
        setting: '6.5–7.5 km/h · 1% incline',
        cue: 'Conversational pace: you can speak in short sentences. '
            'Walk-jog intervals are fine if needed.',
      ),
    ],
  ),
  WorkoutDay(
    id: 4,
    title: 'Full Body + HIIT Treadmill',
    focus: 'Full-body circuit · sprint intervals',
    summary:
        'Big full-body movements followed by 10 treadmill sprint intervals. '
        'Short and intense — the highest heart-rate day of the week.',
    color: Color(0xFFFF4D8D),
    exercises: [
      Exercise(
        id: 'd4-warmup',
        name: 'Treadmill Warm-up',
        equipment: Equipment.treadmill,
        sets: 1,
        durationSec: 300,
        restSec: 60,
        met: 4.8,
        setting: 'Build from 5.5 to 7 km/h',
        cue: 'Get warm properly — the sprints come later.',
      ),
      Exercise(
        id: 'd4-thruster',
        name: 'Dumbbell Thruster',
        equipment: Equipment.dumbbell,
        sets: 3,
        reps: 12,
        restSec: 60,
        met: 8.0,
        cue: 'Dumbbells at shoulders, squat, then drive up and press '
            'overhead in one smooth movement.',
      ),
      Exercise(
        id: 'd4-legpress',
        name: 'Leg Press',
        equipment: Equipment.machine,
        sets: 3,
        reps: 15,
        restSec: 60,
        met: 6.0,
        cue: 'Slightly lighter than Day 2. Steady tempo, full range.',
      ),
      Exercise(
        id: 'd4-pushup',
        name: 'Push-up',
        equipment: Equipment.bodyweight,
        sets: 3,
        reps: 12,
        restSec: 45,
        met: 3.8,
        cue: 'Body in a straight line. Knees down or hands on a bench is '
            'fine — keep the reps clean.',
      ),
      Exercise(
        id: 'd4-woodchop',
        name: 'Cable Woodchop',
        equipment: Equipment.machine,
        sets: 3,
        reps: 12,
        perSide: true,
        restSec: 45,
        met: 4.0,
        cue: 'Rotate through your torso and hips, arms stay long. '
            'Control the return.',
      ),
      Exercise(
        id: 'd4-carry',
        name: "Dumbbell Farmer's Carry",
        equipment: Equipment.dumbbell,
        sets: 3,
        durationSec: 40,
        restSec: 45,
        met: 6.0,
        cue: 'Heavy dumbbells, walk tall, shoulders back, short quick steps.',
      ),
      Exercise(
        id: 'd4-hiit',
        name: 'Treadmill Sprint Intervals',
        equipment: Equipment.treadmill,
        sets: 10,
        durationSec: 30,
        restSec: 60,
        met: 11.5,
        restMet: 3.5,
        setting: 'Sprint 11–14 km/h · recover walking 5 km/h',
        cue: 'Each set is a 30 s sprint; the rest timer is your walk '
            'recovery. Step onto the side rails to change speed safely. '
            'Stop if you feel dizzy.',
      ),
      Exercise(
        id: 'd4-cooldown',
        name: 'Cool-down Walk',
        equipment: Equipment.treadmill,
        sets: 1,
        durationSec: 300,
        restSec: 0,
        met: 3.0,
        setting: '4.5 km/h · flat',
        cue: 'Easy walk until your breathing is back to normal.',
      ),
    ],
  ),
];

WorkoutDay? planDayById(int id) {
  for (final d in workoutPlan) {
    if (d.id == id) return d;
  }
  return null;
}
