# FitBurn — 4-day fat-loss gym tracker (Flutter, Android-first)

A dark-mode gym companion with a 4-day weight-loss split (treadmill +
dumbbells + machines), a set/rep tracker, a rest timer that rings on time
with the screen locked, live % completion and a calorie estimator.

## Why Flutter

The hard requirement is a timer that stays accurate in the background. The
reliable way to do that on Android is not to keep code running, but to hand
the alert to the OS (AlarmManager). `flutter_local_notifications` exposes
exactly that with `zonedSchedule(..., AndroidScheduleMode.alarmClock)`, plus
Android's native notification chronometer for a live countdown in the
notification shade. Flutter also gives one fast, consistent UI codebase.

## How the background timer works

```
tap COMPLETE SET
   │
   ├─ rest = {start: now, end: now + 60 s}       ← absolute timestamps, persisted
   ├─ AlarmManager alert scheduled for `end`     ← fires even if the app is dead
   └─ status notification with countdown chrono  ← ticks natively in the shade

phone locked / app backgrounded / process killed
   └─ nothing in Dart needs to run; the alarm rings at `end`

app returns
   └─ state restored from disk → `_tick()` reconciles from timestamps
      (timed sets that finished become logged sets; their rests are
      started from the moment the set actually ended)
```

UI time is always computed as `now − timestamps`, so the timer can't drift.
Pausing freezes the clock and shifts the end time on resume.

## Project structure

```
lib/
  main.dart                      app bootstrap, providers
  theme.dart                     dark theme, colors, big-button sizing
  data/plan.dart                 the 4-day program (sets, reps, rest, MET, cues)
  models/models.dart             Exercise, WorkoutDay, WorkoutLog
  services/
    calories.dart                MET formula
    notification_service.dart    exact alarms + live status notification
  state/
    session_controller.dart      active workout engine (timers, sets, %, kcal)
    profile_controller.dart      body weight, units, keep-awake
    history_controller.dart      saved workouts, weekly stats
  screens/
    home_screen.dart             week progress, day cards, resume banner
    day_detail_screen.dart       exercise list, permissions, start
    workout_screen.dart          live tracker
    summary_screen.dart          post-workout results
    settings_screen.dart         weight, units, test alert
  widgets/
    common.dart                  cards, big button, progress ring, set dots
    rest_timer_panel.dart        big rest countdown, +15 s, skip
    set_tracker_card.dart        rep stepper / timed-set controls
android/app/src/main/AndroidManifest.xml
test/plan_and_calories_test.dart
```

## Setup

1. Create the platform folders, then drop these files on top:

   ```bash
   flutter create --org com.example --platforms android,ios fitburn
   # copy this project's lib/, test/, pubspec.yaml, analysis_options.yaml
   # and android/app/src/main/AndroidManifest.xml over the generated ones
   cd fitburn && flutter pub get
   ```

2. Enable core library desugaring (required by `flutter_local_notifications`).
   In `android/app/build.gradle.kts`:

   ```kotlin
   android {
       compileSdk = 35
       compileOptions {
           isCoreLibraryDesugaringEnabled = true
           sourceCompatibility = JavaVersion.VERSION_11
           targetCompatibility = JavaVersion.VERSION_11
       }
       defaultConfig {
           minSdk = 23
           targetSdk = 35
       }
   }

   dependencies {
       coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
   }
   ```

   Groovy `build.gradle` equivalent: `coreLibraryDesugaringEnabled true` and
   `coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'`.

3. Release builds: if scheduled alerts crash under R8, add to
   `android/app/proguard-rules.pro`:

   ```
   -keep class com.dexterous.** { *; }
   ```

4. Run and test:

   ```bash
   flutter test
   flutter run --release
   ```

   Then Settings → **Send test alert in 10 s**, lock the phone and confirm it
   rings.

## Permissions

| Permission | Why |
|---|---|
| `POST_NOTIFICATIONS` | Show alerts (asked at the first workout). |
| `SCHEDULE_EXACT_ALARM` | Ring exactly on time while locked. Off by default on Android 14+; the app explains and opens the setting once. Without it, alerts fall back to inexact timing. |
| `RECEIVE_BOOT_COMPLETED` | Re-arm pending alerts after a reboot. |
| `VIBRATE`, `WAKE_LOCK` | Vibration and keep-awake. |

No foreground service is used — it isn't needed because nothing has to run
in the background, and it avoids Play Store foreground-service declarations.

## Calorie estimate

`kcal/min = MET × 3.5 × kg ÷ 200`, applied to:
- logged work time at each exercise's MET (rep sets ≈ 3.5 s/rep),
- rest time at the exercise's rest MET (higher for HIIT walk recovery),
- everything else (setting up, walking around) at 2.5 MET.

Expect ±25% accuracy; it's built to be conservative.

## Progress %

Time-weighted: each set counts as its planned work + rest, so the 20-minute
incline walk weighs more than one set of lateral raises. Timed sets add
progress live while their timer runs.

## Customizing the program

Edit `lib/data/plan.dart`. Each `Exercise` takes `sets`, `reps` **or**
`durationSec`, `restSec`, `met`, optional `restMet`, `perSide`, `setting`
and a coaching `cue`. Changing a day's exercise count discards an
in-progress session for that day on next launch (by design).
