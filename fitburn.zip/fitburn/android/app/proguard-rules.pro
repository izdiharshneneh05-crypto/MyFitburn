# FitBurn is a small personal app, so we don't need R8 to shrink or rename
# code. Shrinking kept removing classes that plugins load by name at runtime
# (shared_preferences, Kotlin coroutines, kotlin.Result...), so turn it off.
-dontshrink
-dontoptimize
-dontobfuscate

# Flutter's optional Play Store deferred components reference Play Core,
# which this app doesn't include. Don't fail the build over it.
-dontwarn com.google.android.play.core.**
-dontwarn com.google.gson.**
-dontwarn kotlinx.coroutines.**

-keepattributes Signature,*Annotation*,InnerClasses,EnclosingMethod
