# Release builds are shrunk by R8. Plugins call these classes by name from
# native/Dart code, so R8 must not remove or rename them.

# shared_preferences (and other Flutter plugins)
-keep class io.flutter.plugins.** { *; }

# Dart JNI bridge used by newer plugin versions
-keep class com.github.dart_lang.jni.** { *; }
-keep class dev.flutter.** { *; }

# Kotlin coroutines (plugin methods take a Continuation)
-keep class kotlin.coroutines.** { *; }
-keep class kotlinx.coroutines.** { *; }
-keep class kotlin.Metadata { *; }
-dontwarn kotlinx.coroutines.**

# AndroidX DataStore (backs shared_preferences)
-keep class androidx.datastore.** { *; }

# flutter_local_notifications stores scheduled alerts with Gson.
-keep class com.dexterous.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes InnerClasses,EnclosingMethod
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken
-dontwarn com.google.gson.**

# wakelock_plus
-keep class dev.fluttercommunity.plus.** { *; }

# Flutter's optional Play Store deferred components reference Play Core,
# which this app doesn't use. Don't fail the build over it.
-dontwarn com.google.android.play.core.**
