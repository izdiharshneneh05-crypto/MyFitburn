# flutter_local_notifications stores scheduled alerts with Gson.
# Without these rules, release (R8-shrunk) builds can crash at runtime.
-keep class com.dexterous.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken
-dontwarn com.google.gson.**
