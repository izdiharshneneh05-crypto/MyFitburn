import 'package:fitburn/data/plan.dart';
import 'package:fitburn/services/calories.dart';
import 'package:fitburn/utils/format.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Calories', () {
    test('MET formula: 80 kg at 8 MET for 30 min ≈ 336 kcal', () {
      expect(Calories.fromMet(8, 30 * 60, 80), closeTo(336, 0.01));
    });

    test('scales linearly with body weight', () {
      final a = Calories.fromMet(5, 600, 60);
      final b = Calories.fromMet(5, 600, 120);
      expect(b, closeTo(a * 2, 1e-9));
    });
  });

  group('Workout plan', () {
    test('has 4 days with ids 1–4', () {
      expect(workoutPlan.map((d) => d.id), [1, 2, 3, 4]);
    });

    test('every day mixes treadmill, dumbbells and machines', () {
      for (final d in workoutPlan) {
        final kinds = d.exercises.map((e) => e.equipment.name).toSet();
        expect(kinds, containsAll(['treadmill', 'dumbbell']),
            reason: 'Day ${d.id}');
        expect(kinds.contains('machine'), isTrue, reason: 'Day ${d.id}');
      }
    });

    test('exercise ids are unique within a day', () {
      for (final d in workoutPlan) {
        final ids = d.exercises.map((e) => e.id).toList();
        expect(ids.toSet().length, ids.length, reason: 'Day ${d.id}');
      }
    });

    test('sessions land in a realistic 40–75 minute window', () {
      for (final d in workoutPlan) {
        expect(d.plannedMinutes, inInclusiveRange(40, 75),
            reason: 'Day ${d.id}: ${d.plannedMinutes} min');
      }
    });

    test('planned calories are plausible for an 80 kg adult', () {
      for (final d in workoutPlan) {
        expect(d.plannedKcal(80), inInclusiveRange(250, 700),
            reason: 'Day ${d.id}');
      }
    });
  });

  test('clock formatting', () {
    expect(fmtClock(0), '0:00');
    expect(fmtClock(75), '1:15');
    expect(fmtClock(3725), '1:02:05');
    expect(fmtDur(90), '1 min 30 s');
  });
}
